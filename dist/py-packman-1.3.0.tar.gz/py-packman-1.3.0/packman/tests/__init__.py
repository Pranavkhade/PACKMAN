"""
To Do:
    1. Add hinge prediction test cases.
"""