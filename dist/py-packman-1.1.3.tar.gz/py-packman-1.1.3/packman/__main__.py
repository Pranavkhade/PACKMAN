from .bin import PACKMAN

if(__name__=='__main__'):
    PACKMAN.main()