from .Constants import amino_acid_molecular_weight
from .Constants import atomic_weight